import { Metadata } from "next";
import DashboardClient from "../dashboard/DashboardClient";

export const metadata: Metadata = {
  title: "Security Settings | Admin Dashboard",
  description: "Manage security settings and passwords",
};

export default function SecurityPage() {
  return (
    <DashboardClient authors={[]} overrideTitle="Security Settings" overrideSubtitle="Manage your account security and password.">
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 sm:p-10 border-b border-slate-200">
          <h2 className="text-xl font-semibold text-slate-800">Change Password</h2>
          <p className="text-slate-500 mt-1">Update your password to keep your account secure.</p>
        </div>
        
        <div className="p-6 sm:p-10">
          <div className="max-w-md">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Current Password</label>
                <input 
                  type="password" 
                  disabled
                  placeholder="Not implemented in this demo"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-500 cursor-not-allowed"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">New Password</label>
                <input 
                  type="password" 
                  disabled
                  placeholder="Not implemented in this demo"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-500 cursor-not-allowed"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Confirm New Password</label>
                <input 
                  type="password" 
                  disabled
                  placeholder="Not implemented in this demo"
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-slate-50 text-slate-500 cursor-not-allowed"
                />
              </div>
              
              <button 
                disabled
                className="mt-6 px-4 py-2 bg-indigo-600 text-white font-medium rounded-lg opacity-50 cursor-not-allowed"
              >
                Update Password
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardClient>
  );
}
